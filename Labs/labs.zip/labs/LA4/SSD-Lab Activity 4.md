SSD-Lab Activity 4
=================
HTML file from previous lab has been used.
A survey form is added and the required tasks have been performed.

### part(a)
An option for a dropdown list is displayed on clicking on `FAQ` button.

### part(b)
A button named `change background` changes the background image. The image is directly sourced from the internet.  

### part(c )
A field named `PIN` prompts for a pincode number. If numeral `3` is entered, a pop box bos is displayed.
### part(d )
Blinking text 

