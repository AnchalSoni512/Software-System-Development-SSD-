var myOptions = {
    val1 : "Buy Mask",
    val2 : "Buy Gloves",
    val3 : "Buy Oxymeter",
    val4 : "Buy thermometer",
    val5 : "Buy Sanitizer"
};
var mySelect = $('#menu');
$.each(myOptions, function(val, text){
    mySelect.append(
        $('<option></option>').val(val).html(text)
    );
});

$(document).ready(function() {
    $("#backgroundChangeButton").click(function() {
        $('body').css('background-image','url(1.jpg)');
        $('body').css('background-repeat','no-repeat');
        $('body').css('background-size','cover');
    });
});

$(document).ready(function() {
    $("#phoneNumber").keydown(function(e){
        if(e.which == 51)
            alert("You typed 3");
    });
});

$(document).ready(function(){
    setInterval(function(){
        $("#blink").fadeIn(300).fadeOut(500);
    },1000);
});