// ----------for blinking----------
setInterval(function(){
  
    $('.blink').fadeOut(500);
    $('.blink').fadeIn(500);
  
}, 1000);


// ------------for background image-------------
$(document).ready(function() {
  $("#cb").click(function() {
    $("body").css(
      "background-image",
      "url(https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS31hoyjco26eWMNrPM7WZhvyeFWvzlHMw48Q&amp;usqp=CAU)"
    );
    $("body").css("background-repeat", "no-repeat");
    $("body").css("background-size", "cover");
  });
});


// -----------------for input 3----------------------
$(document).on("keypress", "input", function(e) {
  if (e.which == 51) {
    var inputVal = $(this).val();

    alert("You've entered 3 " + inputVal);
  }
});
// ---------------------------------------------------------

// function myFunction() {
//   document.getElementById("myDropdown").classList.toggle("show");
// }

// window.onclick = function(event) {
//   if (!event.target.matches('.dropbtn')) {
//     var dropdowns = document.getElementsByClassName("dropdown-content");
//     var i;
//     for (i = 0; i < dropdowns.length; i++) {
//       var openDropdown = dropdowns[i];
//       if (openDropdown.classList.contains('show')) {
//         openDropdown.classList.remove('show');
//       }
//     }
//   }
// } 
$(document).ready(function() {
  $('#generate').click(function() {

    var values = ["WHO", "Doctors", "corona vaccine", "School reopen", "economy"];

    $('#container')
      .append(
        $(document.createElement('label')).prop({
          for: 'pets'
        }).html('Know more about: ')
      )
      .append(
        $(document.createElement('select')).prop({
          id: 'pets',
          name: 'pets'
        })
      )

    for (const val of values) {
      $('#pets').append($(document.createElement('option')).prop({
        value: val,
        text: val.charAt(0).toUpperCase() + val.slice(1)
      }))
    }
  })
});