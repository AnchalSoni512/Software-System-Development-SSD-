#!/bin/bash

echo ***know ur grad year***
read -p "what curent?" cyear
case $cyear in

"1") grad_year="2022";;
"2") grad_year="2021";;
"3") grad_year="2020";;
"4" | "5") grad_year="2019";;
*) echo "dont ask me now!"
exit
esac

echo "youll be graduated in $grad_year"
echo
