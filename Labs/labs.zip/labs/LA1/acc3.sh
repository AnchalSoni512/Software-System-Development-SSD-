#!/bin/bash

#Activity 3

#1-
cal > out1.txt

#2-
date >> out1.txt

#3-
cat out1.txt

#4-
tail -n 3 out1.txt

#5-
cat out1.txt | head -n 7 | tail -n 5

#6-
cat out1.txt | head -n 7 | tail -n 5 | wc -l

#7-
echo "This day is awesome" >> out2.txt

#8-
cat out2.txt | wc -l

#9-
echo "I am looking forward to the day" >> out2.txt

#10-
cat out2.txt | wc -l

#11-
awk '{print $5}' out1.txt

#12-
awk '//{print $4,$5,$6,$7,$8,$9}' out1.txt

#13-
awk '//{print $4,$5,$6,$7,$8,$9}' out1.txt

#14-
awk '//{print $4,$5,$6,$7,$8,$9}' out1.txt
