#!/bin/bash

#Activity 1

#1-chnge cd to /usr/local/lib
cd /usr/local/lib

#2-switch back
cd

#3- chnange from this to /usr/src using relative path
cd /
cd usr
cd src

#4- goto users home dir in one command
cd /home

#5- in home dir create dir using lab activty1
cd /home/anchal_soni/Documents
mkdir LabActivity1

#6- enter this dir.
cd LabActivity1

