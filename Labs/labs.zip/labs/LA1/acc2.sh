#!/bin/bash

#Activity2

#1- displays all occurences of to(case insensitive)
  grep -i to < hamlet.txt
  #for displaying count of all occurances of to (case insensitive )
  grep -i to < hamlet.txt | wc -l

#2-display all lines with "is" not as a part of any other word
  grep -w is < hamlet.txt

#3-display 2 lines below the word "bear"
  grep -w -A 2 --color bear hamlet.txt | grep -v bear

#4- rremove read write and exec access using symbolic
  chmod g-rwx hamlet.txt #for group
  chmod o-rwx hamlet.txt #for others
  chmod 700 hamlet.txt   #in octal

#5- allow everyone to rwx the same file using a single command
  chmod 777 hamlet.txt

#6-view all groups that current user acc is attatched to(in list format)
  groups | tr " " "\n"

#7- change the group of the file hamlet.txt using chown
chown :anchal_soni hamlet.txt

#8-list all the files from your home directory for which group has exwcute permission
ls -l | grep "^......x..."
