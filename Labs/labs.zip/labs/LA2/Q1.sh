#1/bin/bash

#assuming single line contains single word starting with s
grep -E '\bs[^a]' $1



