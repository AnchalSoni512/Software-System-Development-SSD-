# SSD-Lab-Activity-2

## 1. awk activity
### Q 1
* for the text input assuming single line contains single word starting with `s`.Input `.txt` file as an argument.

### Q 2
* command is case sensitive hence does not replaces `work` having one or more letters in capital.
For case insensitive `-i` can be used. Input .txt file as an argument.

### Q 3
* `sed` command is used to replace any character with `#` starting from fifth letter of the password. Input `.txt` file as an argument.

### Q 4
* Used awk command to perform the task. Input `.txt` file as an argument.

### Q 5
* `sed` command is used with regular expression passed to recognise numeric input pattern and change its orderng to flip the atm card number. Input `.txt` file as an argument.

## 2. Git activity

*link to repository- https://github.com/AnchalSoni512/SSD-Lab-Activity-2/
*commands:
 -git clone https://github.com/AnchalSoni512/SSD-Lab-Activity-2.git
-mkdir Lab Activity 2
-cd Lab Activity 2
-touch README.md
-git add README.md
-git commit -m "Add readme.md"
-touch hello_world.txt
-git add hello_world.txt
-git commit -m "Add hello_world.txt"

