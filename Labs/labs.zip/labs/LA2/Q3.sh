#!/bin/bash

sed -e 's/./#/g5' $1
