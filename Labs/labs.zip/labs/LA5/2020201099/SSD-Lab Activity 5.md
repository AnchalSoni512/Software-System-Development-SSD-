SSD-Lab Activity 5
=================
List of assumptions for this lab task.
Each subsection contains two points. First point corresponds to Input format and second point corresponds to output format.

### Q1
* Input should be two integers separated by space by the user.
* Prints the largest number.
### Q2
* Takes a single character input by the user.
* Prints `True` if entered character is a vowel else prints `False`.

### Q3
* user inputs a list of words separated by `,` .
* Prints the length of entered words seperated by `,`.
 e.g. input=> red,blue,black
       output=> 3,4,5
### Q4
* Takes a string as input from the user.
* prints the entered string in reverse order.

