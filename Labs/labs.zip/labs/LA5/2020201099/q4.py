str=input("enter a string: ")
res = str[::-1]
print(res)
