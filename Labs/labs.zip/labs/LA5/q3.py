
a=input().split(',')
length=[]

for i in a:
  length.append(len(i))
#print(length)


str1=""
for ele in length:
  str1+=str(ele)+','


print(str1[:len(str1)-1])
