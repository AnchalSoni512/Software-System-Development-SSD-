
a,b=map(int,input().split(" "))
n1=int(a)
n2=int(b)

if n1 >= n2: 
        print(n1) 
else: 
        print(n2) 

