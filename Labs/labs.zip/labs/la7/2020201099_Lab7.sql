#q1 
select Fname,Lname from EMPLOYEE where Super_ssn in (select Ssn from EMPLOYEE where Fname = 'Jennifer' and Lname = 'Wallace');

#q2
select Fname,Lname from EMPLOYEE E,DEPENDENT D where E.Ssn = D.Essn and E.Fname = D.Dependent_name and E.Sex = D.Sex;

#q3
select distinct Fname,Lname from EMPLOYEE e,PROJECT p,WORKS_ON w where e.Dno="5" and e.Ssn=w.Essn and w.Pno=(select Pnumber from PROJECT where Pname="ProductX" and Dnum="5") and w.Hours>"10.0";

#q4
select p.Pnumber, p.Dnum, e.Lname, e.Address, e.Bdate from PROJECT p, DEPARTMENT d, EMPLOYEE e where p.Dnum = d.Dnumber and d.Mgr_ssn = e.Ssn and p.Plocation = 'Stafford';

#q5
select Lname, Fname
from EMPLOYEE
where not exists ( select *
                  from WORKS_ON B
                  where ( B.Pno in ( select Pnumber
                                    from PROJECT
                                    where Dnum=5 )
                  and
                  not exists ( select *
                               from WORKS_ON C
                               where C.Essn=Ssn
                               and C.Pno=B.Pno )));