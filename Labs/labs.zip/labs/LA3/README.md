SSD-Lab Activity 3
=================
In this readme.md i am adding only those tags which i have used additionally.
I have created three html file namely index.html, symptoms.html and prevention.html


### Using button tag inside <a> tag:

This creates a button inside anchor tag which makes hyperlink looks like a button and gives more aesthetic to page. 

### function

Inside body tag I have used a funtion which pops up a welcome message everytime index.html is called.  

### CSS

I used mostly inline css and internal css. 


