# Q2 to Check if the string is pangram h alphabet
# word or string must contain each english
import string 

def pangram(str): 
	match = "abcdefghijklmnopqrstuvwxyz"
	for char in match: 
		if char not in str.lower(): 
			return False

	return True
#driver
string = input("enter string: ")
if(pangram(string) == True): 
	print("YES") 
else: 
	print("NO") 

