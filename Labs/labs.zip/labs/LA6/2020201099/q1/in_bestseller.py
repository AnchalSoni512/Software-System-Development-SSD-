import os
import csv
from bs4 import BeautifulSoup as soup
from urllib.request import urlopen

listshow=[]
#listshow=[Name,URL,author,price,numberofratings,avg_rating]
#listshow.append(["Name","URL","Author","Price","No ofratings","Average Rating"])
my_url = "https://www.amazon.in/gp/bestsellers/books/"
url_client = urlopen(my_url)
page_html = url_client.read()
url_client.close()
page_soup = soup(page_html, "html.parser")
containers = page_soup.findAll("span",{"class":"aok-inline-block zg-item"})
for container in containers:
  
    title = container.find("div",{"class" : "p13n-sc-truncate"}).string.strip()
    Link = "https://www.amazon.in" + container.find("a",{"class":"a-link-normal"})['href']
    #author = container.find("a",{"class":"a-link-child"})
    try:
      author = container.find("a",{"class":"a-size-small a-link-child"}).string.strip()
    except AttributeError:
      author = "Not Available"

    price = container.find("span",{"class","p13n-sc-price"}).string.strip()
    numberofratings = container.find("a",{"class" : "a-size-small a-link-normal"}).string.strip()
    rating = container.find("span",{"class","a-icon-alt"}).string.strip()

    mylist=[]
    mylist.append(title)
    mylist.append(Link)
    mylist.append(author)
    mylist.append(price)
    mylist.append(numberofratings)
    mylist.append(rating)

    listshow.append(mylist)

my_url = "https://www.amazon.in/gp/bestsellers/books/ref=zg_bs_pg_2?ie=UTF8&pg=2"
url_client = urlopen(my_url)
page_html = url_client.read()
url_client.close()
page_soup = soup(page_html, "html.parser")
containers = page_soup.findAll("span",{"class":"aok-inline-block zg-item"})
for container in containers:
  
    title = container.find("div",{"class" : "p13n-sc-truncate"}).string.strip()
    Link = "https://www.amazon.in" + container.find("a",{"class":"a-link-normal"})['href']
    #author = container.find("a",{"class":"a-link-child"})
    try:
      author = container.find("a",{"class":"a-size-small a-link-child"}).string.strip()
    except AttributeError:
      author = "Not Available"

    price = container.find("span",{"class","p13n-sc-price"}).string.strip()
    numberofratings = container.find("a",{"class" : "a-size-small a-link-normal"}).string.strip()
    rating = container.find("span",{"class","a-icon-alt"}).string.strip()

    mylist=[]
    mylist.append(title)
    mylist.append(Link)
    mylist.append(author)
    mylist.append(price)
    mylist.append(numberofratings)
    mylist.append(rating)

    listshow.append(mylist)

  # print(title + "\t\t " +  author + "\t\t " + price+ "\t\t" +numberofratings +"\t\t" + rating + "\t\t" + Link)

os.mkdir("output")
with open('output/in_book.csv', 'w', encoding="utf-8") as file:
    writer = csv.writer(file,lineterminator = '\n')
    #writer = csv.writer(file,delimiter=';')
    writer.writerows(listshow)
