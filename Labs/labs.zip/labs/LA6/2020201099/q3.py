#Q3
#names = ['sally', 'Dylan', 'rebecca', 'Diana', 'Joanne', 'keith']
names = [] 
#n =int(input("Enter number of names you would enter : ")) 
print("enter comma seperataed names")
input_names = input()
names = [x for x in input_names.split(',')]
names=list(filter(lambda element:element[0].isupper() and element[1:].islower(),names))
#print("Result:")
print(len(''.join(names)))
