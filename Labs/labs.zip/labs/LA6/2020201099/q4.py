#print("Please provide multiple sets of binary numbers that are comma separated: ")
binary_numbers = input()
 
number_list = [x for x in binary_numbers.split(',')]
divby5 = set()
 
for b in number_list:
    binary_int = int(b, 2)
    if not binary_int % 5:
        divby5.add(b)
 
#print("The list of numbers that are divisible by 5: ")
print(','.join(divby5))
