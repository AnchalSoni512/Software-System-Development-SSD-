SSD-Lab Activity 6
=================
List of assumptions for this lab task.
Each subsection contains two points. First point corresponds to Input format and second point corresponds to output format.

### Q1
* no input required
* prefer opening csv file in notepad.

### Q2
* user input required
* Prints `YES` if entered character is a pangram else prints `NO`.

### Q4
* accepts a sequence of comma separated 4-digit 
* print the numbers that are divisible by 5 in a comma separated sequence.
### Q4
* user input required.
* sum the length of the names of a given list of namesand list itselfafter removing the names that starts with a lowercase letter.


